using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MVC_Task.Data;
using MVC_Task.Data.Repository.BaseRepository;
using MVC_Task.Data.Repository.RepositoryCourse;
using MVC_Task.Data.Repository.RepositoryStudent;
using MVC_Task.Services.CourseService;
using MVC_Task.Services.StudentService;
using System.IO;

namespace MVC_Task.UI
{
    public class Startup
    {
        public IConfiguration _configuration { get; }
        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews();
            services.AddDbContext<DataContext>(x => x.UseSqlServer(_configuration.GetConnectionString("Connection")));

            services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
            services.AddScoped<IStudentRepository, StudentRepository>();
            services.AddScoped<ICourseRepository, CourseRepository>();
            services.AddScoped<ICourseStudentRepository, CourseStudentRepository>();

            services.AddMvc().AddControllersAsServices();

            services.AddScoped<IStudentService, StudentService>();
            services.AddScoped<ICourseService, CourseService>();
            services.AddTransient<ICourseStudentService, CourseStudentService>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.Use(async (context, next) =>
            {
                try
                {
                    await next();
                }
                catch (System.Exception ex)
                {
                    using (StreamWriter writetext = new StreamWriter("Errors.txt"))
                    {
                        writetext.WriteLine(ex.ToString());
                    }
                    await context.Response.WriteAsync("There is an error in the server.");
                }
            });
            //if (env.IsDevelopment())
            //{
            //    app.UseDeveloperExceptionPage();
            //}

            app.UseRouting();
            app.UseStaticFiles();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
