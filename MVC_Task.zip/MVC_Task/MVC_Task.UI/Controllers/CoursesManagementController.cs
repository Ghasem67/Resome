﻿using Microsoft.AspNetCore.Mvc;
using MVC_Task.Services.CourseService;
using MVC_Task.Utilities.Validation;
using MVC_Task.Utilities.ViewModels;
using Newtonsoft.Json;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MVC_Task.UI.Controllers
{
    public class CoursesManagementController : Controller
    {
        private readonly ICourseService _courseService;
        public CoursesManagementController(ICourseService courseService)
        {
            _courseService = courseService;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<string> CreateCourseAsync(CourseViewModel courseViewModel)
        {
            CancellationToken cancellationToken = new();
            var validate = new Validation().CourseValidate(courseViewModel);
            if (validate == "OK")
            {
              await  _courseService.AddCourseService(courseViewModel,cancellationToken);
                var result = _courseService.GetCourseService().LastOrDefault();
                return JsonConvert.SerializeObject(new { Result = "OK", Record = result });
            }
            else
                return JsonConvert.SerializeObject(new { Result = "ERROR", Message = validate });
        }

        [HttpPost]
        public async Task<string> EditCourseAsync(CourseViewModel courseViewModel)
        {
            CancellationToken cancellationToken = new();
            var validate = new Validation().CourseValidate(courseViewModel);
            if (validate == "OK")
            {
             await   _courseService.EditCourseService(courseViewModel,cancellationToken);
                return JsonConvert.SerializeObject(new { Result = "OK" });
            }
            else
                return JsonConvert.SerializeObject(new { Result = "ERROR", Message = validate });
        }

        [HttpPost]
        public async Task<string> DeleteCourseAsync(CourseViewModel courseViewModel)
        {
            CancellationToken cancellationToken = new();
           await _courseService.DeleteCourseService(courseViewModel,cancellationToken);
            return JsonConvert.SerializeObject(new { Result = "OK" });
        }

        [HttpPost]
        public string GetCourseList()
        {
            var res = _courseService.GetCourseService();
            return JsonConvert.SerializeObject(new { Result = "OK", Records = res.ToList() });
        }
    }
}
