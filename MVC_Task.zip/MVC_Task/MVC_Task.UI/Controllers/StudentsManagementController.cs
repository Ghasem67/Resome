﻿using Microsoft.AspNetCore.Mvc;
using MVC_Task.Services.StudentService;
using MVC_Task.Utilities.Validation;
using MVC_Task.Utilities.ViewModels;
using Newtonsoft.Json;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MVC_Task.UI.Controllers
{
    public class StudentsManagementController : Controller
    {
        private readonly IStudentService _studentService;
        public StudentsManagementController(IStudentService studentService)
        {
            _studentService = studentService;
        }

        public IActionResult Index()
        {
            return View();
        }


        [HttpPost]
        public async Task<string> CreateStudentAsync(StudentViewModel studentViewModel)
        {
            CancellationToken cancellationToken = new();
            var validate = new Validation().StudentValidate(studentViewModel);
            if (validate == "OK")
            {
             await   _studentService.AddStudentService(studentViewModel,cancellationToken);
                
                var result =await _studentService.GetStudentList( cancellationToken);
                return JsonConvert.SerializeObject(new { Result = "OK", Record = result.LastOrDefault() });
            }
            else
                return JsonConvert.SerializeObject(new { Result = "ERROR", Message = validate });
        }

        [HttpPost]
        public async System.Threading.Tasks.Task<string> EditStudentAsync(StudentViewModel studentViewModel)
        {
            CancellationToken cancellationToken = new();
               var validate = new Validation().StudentValidate(studentViewModel);
            if (validate == "OK")
            {
              await  _studentService.EditStudentService(studentViewModel,cancellationToken);
                
                return JsonConvert.SerializeObject(new { Result = "OK" });
            }
            else
                return JsonConvert.SerializeObject(new { Result = "ERROR", Message = validate });
        }

        [HttpPost]
        public async Task<string> DeleteStudentAsync(StudentViewModel studentViewModel)
        {
            CancellationToken cancellationToken = new();
           await _studentService.DeleteStudentService(studentViewModel,cancellationToken);
            return JsonConvert.SerializeObject(new { Result = "OK" });
        }

        [HttpPost]
        public async Task<string> StudentsListAsync(CancellationToken cancellationToken)
        {
            var res =await _studentService.GetStudentList( cancellationToken);
            return JsonConvert.SerializeObject(new { Result = "OK", Records = res });
        }
    }
}
