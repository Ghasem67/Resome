﻿using Microsoft.AspNetCore.Mvc;
using MVC_Task.Services.CourseService;
using MVC_Task.Services.StudentService;
using MVC_Task.Utilities.ViewModels;
using Newtonsoft.Json;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MVC_Task.UI.Controllers
{
    public class StudentsCourseManagementController : Controller
    {
        private readonly ICourseService _courseService;
        private readonly ICourseStudentService _courseStudentService;
        private readonly IStudentService _studentService;
        public StudentsCourseManagementController(ICourseStudentService courseStudentService, IStudentService studentService, ICourseService courseService)
        {
            _courseStudentService = courseStudentService;
            _studentService = studentService;
            _courseService = courseService;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<string> StudentsListAsync(CancellationToken cancellationToken)
        {
            var res =await _studentService.GetStudentList( cancellationToken);
            return JsonConvert.SerializeObject(new { Result = "OK", Records = res.ToList() });
        }

        [HttpPost]
        public string StudentCourseList(int StudentID = 0)
        {
            var res = _courseStudentService.GetCourseOfStudent(StudentID);
            return JsonConvert.SerializeObject(new { Result = "OK", Records = res });
        }

        [HttpPost]
        public string GetCourseList()
        {
            var result = _courseService.GetCourseService();
            var classes = result.ToList().Select(c => new { DisplayText = c.CourseName, Value = c.ID }).ToList();
            return JsonConvert.SerializeObject(new { Result = "OK", Options = classes });
        }

        [HttpPost]
        public async Task<string> AddStudentCourseAsync(int StudentID, int Courses)
        {
            CancellationToken cancellationToken = new();
            var res =await _courseStudentService.AddCourseStudent(new CourseStudentViewModel { CourseID = Courses, StudentID = StudentID },cancellationToken);
            if (res >= 0)
            {
                var res2 = _courseStudentService.GetCourseOfStudent(StudentID).LastOrDefault();
                return JsonConvert.SerializeObject(new { Result = "OK", Record = res2 });
            }
            else
            {
                switch (res)
                {
                    case -1:
                        return JsonConvert.SerializeObject(new { Result = "ERROR", Message = "The capacity to obtain a student lesson has been completed" });
                    case -2:
                        return JsonConvert.SerializeObject(new { Result = "ERROR", Message = "Student recently obtained this course" });
                    case -3:
                        return JsonConvert.SerializeObject(new { Result = "ERROR", Message = "The capacity of class has been completed" });
                    default:
                        return JsonConvert.SerializeObject(new { Result = "ERROR", Message = "There is an error to obtaining this course" });
                }
            }
        }

        [HttpPost]
        public string DeleteStudentCourse(int StudentID, int ID)
        {
            CancellationToken cancellationToken = new();
            _courseStudentService.DeleteCourseStudent(StudentID, ID,cancellationToken);
            return JsonConvert.SerializeObject(new { Result = "OK" });
        }
    }
}
