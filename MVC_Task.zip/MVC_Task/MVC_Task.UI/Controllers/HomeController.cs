﻿using Microsoft.AspNetCore.Mvc;

namespace MVC_Task.UI.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
