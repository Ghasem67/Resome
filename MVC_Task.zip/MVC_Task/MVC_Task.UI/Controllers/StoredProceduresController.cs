﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MVC_Task.Data;
using MVC_Task.Services.CourseService;
using MVC_Task.Services.StudentService;
using Newtonsoft.Json;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MVC_Task.UI.Controllers
{
    public class StoredProceduresController : Controller
    {
        private readonly DataContext dataContext;
        private readonly ICourseService _courseService;
        private readonly IStudentService _studentService;

        public StoredProceduresController(DataContext dataContext, ICourseService courseService, IStudentService studentService)
        {
            this.dataContext = dataContext;
            _courseService = courseService;
            _studentService = studentService;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<string> Query1Async(CancellationToken cancellationToken)
        {
            var result =await _studentService.GetStudentList( cancellationToken);
            return JsonConvert.SerializeObject(new { Result = "OK", Records = result });
        }

        [HttpPost]
        public string Query1_1(string StudentID)
        {
            var result = dataContext.Courses.FromSqlRaw(@"StudentCourseList " + StudentID).ToList();
            return JsonConvert.SerializeObject(new { Result = "OK", Records = result });
        }

        [HttpPost]
        public string Query2()
        {
            var result = _courseService.GetCourseService();
            return JsonConvert.SerializeObject(new { Result = "OK", Records = result });
        }

        [HttpPost]
        public string Query2_1(string CourseID)
        {
            var result = dataContext.Students.FromSqlRaw(@"CourseStudentList " + CourseID).ToList();
            return JsonConvert.SerializeObject(new { Result = "OK", Records = result });
        }

        [HttpPost]
        public string Query3()
        {
            var result = dataContext.Students.FromSqlRaw("RemainedStudents").ToList();
            return JsonConvert.SerializeObject(new { Result = "OK", Records = result });
        }

        [HttpPost]
        public string Query4()
        {
            var result = dataContext.Courses.FromSqlRaw("RemainedCourses").ToList();
            return JsonConvert.SerializeObject(new { Result = "OK", Records = result });
        }
    }
}
