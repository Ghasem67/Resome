﻿namespace MVC_Task.Utilities.Enums
{
    public enum GenderType
    {
        Male = 0,
        Female = 1
    }
}
