﻿using MVC_Task.Utilities.ViewModels;
using System.Text.RegularExpressions;

namespace MVC_Task.Utilities.Validation
{
    public class Validation
    {
        public string CourseValidate(CourseViewModel courseViewModel)
        {
            if (courseViewModel.CourseCode > 0 && !string.IsNullOrEmpty(courseViewModel.CourseName) && !string.IsNullOrEmpty(courseViewModel.TeacherName) && courseViewModel.MaxStudentCount > 0)
            {
                if (courseViewModel.StartDate <= courseViewModel.EndDate)
                {
                    if (new Regex(@"^[0-9]+$").IsMatch(courseViewModel.CourseCode.ToString()))
                    {
                        if (new Regex(@"^[0-9]+$").IsMatch(courseViewModel.MaxStudentCount.ToString()))
                        {
                            return "OK";
                        }
                        else
                            return "Max Student Count must only be digits";
                    }
                    else
                        return "Course Code must only be digits";
                }
                else
                    return "Start date must be before the end date";
            }
            else
                return "Please complete the required fields";
        }

        public string StudentValidate(StudentViewModel studentViewModel)
        {
            if (!string.IsNullOrEmpty(studentViewModel.FirstName) && !string.IsNullOrEmpty(studentViewModel.SureName) && !string.IsNullOrEmpty(studentViewModel.Address1))
                return "OK";
            else
                return "Please complete the required fields";
        }

    }
}
