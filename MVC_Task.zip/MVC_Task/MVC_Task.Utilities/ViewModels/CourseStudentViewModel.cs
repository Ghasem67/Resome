﻿namespace MVC_Task.Utilities.ViewModels
{
    public class CourseStudentViewModel
    {
        public int ID { get; set; }
        public int CourseID { get; set; }
        public int StudentID { get; set; }
    }
}
