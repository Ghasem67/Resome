﻿using System;
using System.ComponentModel.DataAnnotations;

namespace MVC_Task.Utilities.ViewModels
{
    public class CourseViewModel
    {
        public int ID { get; set; }
        [Required]
        public int CourseCode { get; set; }
        [Required]
        [MaxLength(50)]
        public string CourseName { get; set; }
        [Required]
        [MaxLength(50)]
        public string TeacherName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int MaxStudentCount { get; set; }
    }
}
