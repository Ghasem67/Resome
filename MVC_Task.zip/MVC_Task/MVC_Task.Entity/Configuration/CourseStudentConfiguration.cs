﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MVC_Task.Entity.EntityCourse;

namespace MVC_Task.Entity.Configuration
{
    public class CourseStudentConfiguration : IEntityTypeConfiguration<CourseStudent>
    {
        public void Configure(EntityTypeBuilder<CourseStudent> builder)
        {
            builder.HasOne(x => x.Student).WithMany(x => x.CourseStudents).HasForeignKey(x => x.StudentID).OnDelete(DeleteBehavior.Cascade);
            builder.HasOne(x => x.Course).WithMany(x => x.CourseStudents).HasForeignKey(x => x.CourseID).OnDelete(DeleteBehavior.Cascade);
        }
    }
}
