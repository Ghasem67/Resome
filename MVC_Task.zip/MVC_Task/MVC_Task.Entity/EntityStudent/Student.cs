﻿using MVC_Task.Entity.EntityCourse;
using MVC_Task.Utilities.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MVC_Task.Entity.EntityStudent
{
    public class Student
    {
        public int ID { get; set; }
        [Required]
        [MaxLength(50)]
        public string FirstName { get; set; }
        [Required]
        [MaxLength(50)]
        public string SureName { get; set; }
        public GenderType Gender { get; set; }
        public DateTime DOB { get; set; }
        [Required]
        [MaxLength(200)]
        public string Address1 { get; set; }
        [MaxLength(200)]
        public string Address2 { get; set; }
        [MaxLength(200)]
        public string Address3 { get; set; }
        public ICollection<CourseStudent> CourseStudents { get; set; }
    }
}
