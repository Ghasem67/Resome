﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MVC_Task.Entity.EntityCourse
{
    public class Course
    {
        public int ID { get; set; }
        [Required]
        public int CourseCode { get; set; }
        [Required]
        [MaxLength(50)]
        public string CourseName { get; set; }
        [Required]
        [MaxLength(50)]
        public string TeacherName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int MaxStudentCount { get; set; }
        public ICollection<CourseStudent> CourseStudents { get; set; }
    }
}
