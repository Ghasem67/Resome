﻿using MVC_Task.Entity.EntityStudent;

namespace MVC_Task.Entity.EntityCourse
{
    public class CourseStudent
    {
        public int ID { get; set; }
        public int CourseID { get; set; }
        public Course Course { get; set; }
        public int StudentID { get; set; }
        public Student Student { get; set; }
    }
}
