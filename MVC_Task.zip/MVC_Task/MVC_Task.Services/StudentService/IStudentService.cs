﻿using MVC_Task.Utilities.ViewModels;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace MVC_Task.Services.StudentService
{
    public interface IStudentService
    {
        Task AddStudentService(StudentViewModel studentViewModel,CancellationToken cancellationToken);
        Task EditStudentService(StudentViewModel studentViewModel, CancellationToken cancellationToken);
        Task DeleteStudentService(StudentViewModel studentViewModel, CancellationToken cancellationToken);
       Task <List<StudentViewModel>> GetStudentList(CancellationToken cancellationToken);

    }
}
