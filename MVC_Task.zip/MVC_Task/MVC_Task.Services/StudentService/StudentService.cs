﻿using MVC_Task.Data.Repository.RepositoryStudent;
using MVC_Task.Entity.EntityStudent;
using MVC_Task.Utilities.ViewModels;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MVC_Task.Services.StudentService
{
    public class StudentService : IStudentService
    {
        private readonly IStudentRepository _studentRepository;

        public StudentService(IStudentRepository studentRepository)
        {
            _studentRepository = studentRepository;
        }
        public async Task AddStudentService(StudentViewModel studentViewModel, CancellationToken cancellationToken)
        {

           
            await _studentRepository.AddItem(new Student
            {
                Address1 = studentViewModel.Address1,
                Address2 = studentViewModel.Address2,
                Address3 = studentViewModel.Address3,
                DOB = studentViewModel.DOB,
                FirstName = studentViewModel.FirstName,
                SureName = studentViewModel.SureName,
                Gender = studentViewModel.Gender
            },cancellationToken);
        }

        public async Task DeleteStudentService(StudentViewModel studentViewModel, CancellationToken cancellationToken)
        {
            var student = _studentRepository.GetOneStudent(studentViewModel.ID);
            await _studentRepository.DeleteItem(student, cancellationToken);

        }

        public async Task EditStudentService(StudentViewModel studentViewModel, CancellationToken cancellationToken)
        {
            var course = _studentRepository.GetOneStudent(studentViewModel.ID);
            course.FirstName = studentViewModel.FirstName;
            course.SureName = studentViewModel.SureName;
            course.DOB = studentViewModel.DOB;
            course.Gender = studentViewModel.Gender;
            course.Address1 = studentViewModel.Address1;
            course.Address2 = studentViewModel.Address2;
            course.Address3 = studentViewModel.Address3;
            await _studentRepository.EditItem(course, cancellationToken);
        }

       

        public async Task<List<StudentViewModel>> GetStudentList(CancellationToken cancellationToken)
        {
            var Result = await _studentRepository.GetStudentList(cancellationToken);
            return Result.Select(x => new StudentViewModel
            {
                ID = x.ID,
                FirstName = x.FirstName,
                DOB = x.DOB,
                Address1 = x.Address1,
                Address2 = x.Address2,
                Address3 = x.Address3,
                Gender = x.Gender,
                SureName = x.SureName
            }).ToList();
        }

       
    }
}
