﻿using MVC_Task.Utilities.ViewModels;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace MVC_Task.Services.CourseService
{
    public interface ICourseStudentService
    {
        Task<int> AddCourseStudent(CourseStudentViewModel courseStudentViewModel,CancellationToken cancellationToken);
        Task DeleteCourseStudent(int StudentID, int CourseID, CancellationToken cancellationToken);
        List<StudentViewModel> GetStudentsOfCourse(int ID);
        List<CourseViewModel> GetCourseOfStudent(int ID);
    }
}
