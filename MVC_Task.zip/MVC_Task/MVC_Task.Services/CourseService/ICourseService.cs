﻿using MVC_Task.Utilities.ViewModels;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace MVC_Task.Services.CourseService
{
    public interface ICourseService
    {
        Task AddCourseService(CourseViewModel courseViewModel,CancellationToken cancellationToken);
        Task EditCourseService(CourseViewModel courseViewModel, CancellationToken cancellationToken);
        Task DeleteCourseService(CourseViewModel courseViewModel, CancellationToken cancellationToken);
        List<CourseViewModel> GetCourseService();

    }
}
