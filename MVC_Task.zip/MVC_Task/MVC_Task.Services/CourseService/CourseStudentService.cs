﻿using MVC_Task.Data.Repository.RepositoryCourse;
using MVC_Task.Utilities.ViewModels;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MVC_Task.Services.CourseService
{
    public class CourseStudentService : ICourseStudentService
    {
        private readonly ICourseStudentRepository _courseStudentRepository;
        private readonly ICourseRepository _courseRepository;

        public CourseStudentService(ICourseStudentRepository courseStudentRepository, ICourseRepository courseRepository)
        {
            _courseStudentRepository = courseStudentRepository;
            _courseRepository = courseRepository;
        }
        public async Task<int> AddCourseStudent(CourseStudentViewModel courseStudentViewModel,CancellationToken cancellationToken)
        {
            int result = AddCourseStudentvalidation(courseStudentViewModel);
            if (result == 1)
            {
               await _courseStudentRepository.AddItem(new Entity.EntityCourse.CourseStudent
                {
                    CourseID = courseStudentViewModel.CourseID,
                    StudentID = courseStudentViewModel.StudentID
                }, cancellationToken);
                return result;
            }
            else
            {
                return result;
            }
            
        }

        public async Task DeleteCourseStudent(int StudentID, int CourseID, CancellationToken cancellationToken)
        {
            var course = _courseStudentRepository.SelectCourseStudent(StudentID, CourseID);
            await _courseStudentRepository.DeleteItem(course, cancellationToken);
        }


        public List<CourseViewModel> GetCourseOfStudent(int ID)
        {
            return _courseStudentRepository.GetCourseOfStudent(ID).Select(x => new CourseViewModel
            {
                CourseName = x.CourseName,
                CourseCode = x.CourseCode,
                EndDate = x.EndDate,
                MaxStudentCount = x.MaxStudentCount,
                ID = x.ID,
                StartDate = x.StartDate,
                TeacherName = x.TeacherName
            }).ToList();
        }

        public List<StudentViewModel> GetStudentsOfCourse(int ID)
        {
            return _courseStudentRepository.GetStudentsOfCourse(ID).Select(x => new StudentViewModel
            {
                ID = x.ID,
                Address1 = x.Address1,
                Address2 = x.Address2,
                Address3 = x.Address3,
                DOB = x.DOB,
                FirstName = x.FirstName,
                Gender = x.Gender,
                SureName = x.SureName
            }).ToList();
        }
        private int AddCourseStudentvalidation(CourseStudentViewModel courseStudentViewModel)
        {
            var CourseOfStudent = _courseStudentRepository.GetCourseOfStudent(courseStudentViewModel.StudentID).ToList();
            if (CourseOfStudent.Count() < 5)
            {
                if (CourseOfStudent.FirstOrDefault(x => x.ID.Equals(courseStudentViewModel.CourseID)) == null)
                {
                    var CourseStudent = _courseStudentRepository.GetStudentsOfCourse(courseStudentViewModel.CourseID);
                    if (CourseStudent.Count < _courseRepository.GetOneCourse(courseStudentViewModel.CourseID).MaxStudentCount)
                    {
                        return 1;
                       
                    }
                    else return -3;
                }
                else return -2;
            }
            else return -1;
        }
    }
}
