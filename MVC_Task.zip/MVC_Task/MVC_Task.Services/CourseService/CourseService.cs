﻿using MVC_Task.Data.Repository.RepositoryCourse;
using MVC_Task.Entity.EntityCourse;
using MVC_Task.Utilities.ViewModels;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MVC_Task.Services.CourseService
{
    public class CourseService : ICourseService
    {
        private readonly ICourseRepository _courseRepository;

        public CourseService(ICourseRepository courseRepository)
        {
            _courseRepository = courseRepository;
        }

        public async Task AddCourseService(CourseViewModel courseViewModel, CancellationToken cancellationToken)
        {
            await _courseRepository.AddItem(new Course
            {
                CourseCode = courseViewModel.CourseCode,
                CourseName = courseViewModel.CourseName,
                EndDate = courseViewModel.EndDate,
                StartDate = courseViewModel.StartDate,
                TeacherName = courseViewModel.TeacherName,
                MaxStudentCount = courseViewModel.MaxStudentCount
            }, cancellationToken);
        }

       

        public async Task DeleteCourseService(CourseViewModel courseViewModel, CancellationToken cancellationToken)
        {

            var course = _courseRepository.GetOneCourse(courseViewModel.ID);
            await _courseRepository.DeleteItem(course,cancellationToken);
        }

        public async Task EditCourseService(CourseViewModel courseViewModel, CancellationToken cancellationToken)
        {
            var course = _courseRepository.GetOneCourse(courseViewModel.ID);
            course.CourseCode = courseViewModel.CourseCode;
            course.CourseName = courseViewModel.CourseName;
            course.TeacherName = courseViewModel.TeacherName;
            course.EndDate = courseViewModel.EndDate;
            course.StartDate = courseViewModel.StartDate;
            course.MaxStudentCount = courseViewModel.MaxStudentCount;
            await _courseRepository.EditItem(course, cancellationToken);
        }

       

        public List<CourseViewModel> GetCourseService()
        {

            var result = _courseRepository.GetCourseList();
            return result.Select(x => new CourseViewModel
            {
                CourseCode = x.CourseCode,
                CourseName = x.CourseName,
                EndDate = x.EndDate,
                ID = x.ID,
                MaxStudentCount = x.MaxStudentCount,
                StartDate = x.StartDate,
                TeacherName = x.TeacherName
            }).ToList();
        }

      
    }
}
