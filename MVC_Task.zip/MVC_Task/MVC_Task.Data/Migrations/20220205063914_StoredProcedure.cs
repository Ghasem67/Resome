﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MVC_Task.Data.Migrations
{
    public partial class StoredProcedure : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            var Q1 = @"CREATE PROCEDURE StudentCourseList (@CrsID int)
                    AS
                    BEGIN
                    SELECT Courses.ID, CourseCode,CourseName,TeacherName,StartDate,EndDate,MaxStudentCount FROM Courses
                    INNER JOIN CourseStudents
                    ON Courses.ID = CourseStudents.CourseID
                    WHERE CourseStudents.StudentID = @CrsID
                    END";
            migrationBuilder.Sql(Q1);

            var Q2 = @"CREATE PROCEDURE CourseStudentList (@StdID int)
                    AS
                    BEGIN
                    SELECT Students.ID,FirstName,SureName,Gender,DOB,Address1,Address2,Address3 FROM Students
                    INNER JOIN CourseStudents
                    ON Students.ID = CourseStudents.StudentID
                    WHERE CourseStudents.CourseID = @StdID
                    END";
            migrationBuilder.Sql(Q2);

            var Q3 = @"CREATE PROCEDURE RemainedStudents 
                    AS
                    BEGIN
                    Select * from Students where(Select count(*) from CourseStudents where StudentID=Students.ID)<5
                    END";
            migrationBuilder.Sql(Q3);

            var Q4 = @"CREATE PROCEDURE RemainedCourses
                    AS
                    BEGIN
                    Select * from Courses where(Select count(*) from CourseStudents where CourseID=Courses.ID)<Courses.MaxStudentCount
                    END";
            migrationBuilder.Sql(Q4);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
