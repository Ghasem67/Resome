﻿using MVC_Task.Data.Repository.BaseRepository;
using MVC_Task.Entity.EntityCourse;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MVC_Task.Data.Repository.RepositoryCourse
{
    public interface ICourseRepository : IRepository<Course>
    {
        Course GetOneCourse(int ID);
        List<Course> GetCourseList();
        //Task EditItem(Course course, object cancellationToken);
        //Task DeleteItem(Course course, object cancellationToken);
    }
}
