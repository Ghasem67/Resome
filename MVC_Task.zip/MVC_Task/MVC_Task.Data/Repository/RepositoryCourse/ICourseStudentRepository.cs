﻿using MVC_Task.Data.Repository.BaseRepository;
using MVC_Task.Entity.EntityCourse;
using MVC_Task.Entity.EntityStudent;
using System.Collections.Generic;

namespace MVC_Task.Data.Repository.RepositoryCourse
{
    public interface ICourseStudentRepository : IRepository<CourseStudent>
    {
        CourseStudent GetOneCourseStudent(int ID);
        List<Student> GetStudentsOfCourse(int courseID);
        List<Course> GetCourseOfStudent(int studentID);
        CourseStudent SelectCourseStudent(int studentID, int CourseId);
    }
}
