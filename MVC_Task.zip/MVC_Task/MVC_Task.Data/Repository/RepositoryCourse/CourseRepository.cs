﻿using MVC_Task.Entity.EntityCourse;
using System.Collections.Generic;
using System.Linq;

namespace MVC_Task.Data.Repository.RepositoryCourse
{
    public class CourseRepository : BaseRepository.Repository<Course>, ICourseRepository
    {
        public CourseRepository(DataContext dataContext) : base(dataContext)
        {
        }

        public Course GetOneCourse(int ID)
        {
            return _dataContext.Courses.FirstOrDefault(x => x.ID.Equals(ID));
        }

        public List<Course> GetCourseList()
        {
            return _dataContext.Courses.ToList();
        }



    }
}
