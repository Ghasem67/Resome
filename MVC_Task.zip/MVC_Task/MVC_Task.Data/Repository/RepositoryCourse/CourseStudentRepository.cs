﻿using MVC_Task.Entity.EntityCourse;
using MVC_Task.Entity.EntityStudent;
using System.Collections.Generic;
using System.Linq;

namespace MVC_Task.Data.Repository.RepositoryCourse
{
    public class CourseStudentRepository : BaseRepository.Repository<CourseStudent>, ICourseStudentRepository
    {
        public CourseStudentRepository(DataContext dataContext) : base(dataContext)
        {

        }
        public CourseStudent GetOneCourseStudent(int ID)
        {
            return _dataContext.CourseStudents.FirstOrDefault(x => x.ID.Equals(ID));
        }

        public List<Course> GetCourseOfStudent(int StudentID)
        {
            return _dataContext.CourseStudents.Where(x => x.StudentID.Equals(StudentID)).Select(x => x.Course).ToList();
        }

        public List<Student> GetStudentsOfCourse(int courseID)
        {
            return _dataContext.CourseStudents.Where(x => x.CourseID.Equals(courseID)).Select(x => x.Student).ToList();
        }

        public CourseStudent SelectCourseStudent(int StudentID, int CourseId)
        {
            return _dataContext.CourseStudents.Where(x => x.CourseID.Equals(CourseId) && x.StudentID.Equals(StudentID)).FirstOrDefault();
        }

    }
}
