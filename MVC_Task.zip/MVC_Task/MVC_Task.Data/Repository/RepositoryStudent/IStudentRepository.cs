﻿using MVC_Task.Data.Repository.BaseRepository;
using MVC_Task.Entity.EntityStudent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace MVC_Task.Data.Repository.RepositoryStudent
{
    public interface IStudentRepository : IRepository<Student>
    {
        Student GetOneStudent(int ID);
        Task<List<Student>> GetStudentList(CancellationToken cancellationToken);

    }
}
