﻿using Microsoft.EntityFrameworkCore;
using MVC_Task.Entity.EntityStudent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MVC_Task.Data.Repository.RepositoryStudent
{
    public class StudentRepository : BaseRepository.Repository<Student>, IStudentRepository
    {
        public StudentRepository(DataContext dataContext) : base(dataContext)
        {
        }

        public Student GetOneStudent(int ID)
        {
            return _dataContext.Students.FirstOrDefault(x => x.ID.Equals(ID));
        }

        public async Task<List<Student>> GetStudentList(CancellationToken cancellationToken)
        {
            return await _dataContext.Students.ToListAsync(cancellationToken);
        }



    }
}
