﻿using System.Threading;
using System.Threading.Tasks;

namespace MVC_Task.Data.Repository.BaseRepository
{
    public class Repository<TEntity> : IRepository<TEntity>
    {
        public Repository(DataContext dataContext)
        {
            _dataContext = dataContext;
        }

        protected readonly DataContext _dataContext;

        public async Task AddItem(TEntity entity,CancellationToken cancellationToken)
        {

            _dataContext.Add(entity);
            await _dataContext.SaveChangesAsync(cancellationToken);
        }

        public async Task DeleteItem(TEntity entity, CancellationToken cancellationToken)
        {
            _dataContext.Remove(entity);
            await _dataContext.SaveChangesAsync(cancellationToken);
        }

        public async Task EditItem(TEntity entity, CancellationToken cancellationToken)
        {
            _dataContext.Update(entity);
            await _dataContext.SaveChangesAsync(cancellationToken);
        }

       
    }
}
