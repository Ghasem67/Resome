﻿using System.Threading;
using System.Threading.Tasks;

namespace MVC_Task.Data.Repository.BaseRepository
{
    public interface IRepository<TEntity>
    {
        Task AddItem(TEntity entity,CancellationToken cancellationToken);
        Task EditItem(TEntity entity, CancellationToken cancellationToken);
        Task DeleteItem(TEntity entity, CancellationToken cancellationToken);
    }
}
