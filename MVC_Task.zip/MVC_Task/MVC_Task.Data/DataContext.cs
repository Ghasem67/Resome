﻿using Microsoft.EntityFrameworkCore;
using MVC_Task.Entity.Configuration;
using MVC_Task.Entity.EntityCourse;
using MVC_Task.Entity.EntityStudent;

namespace MVC_Task.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.ApplyConfigurationsFromAssembly(typeof(CourseStudentConfiguration).Assembly);
        }

        public DbSet<Course> Courses { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<CourseStudent> CourseStudents { get; set; }
    }
}
